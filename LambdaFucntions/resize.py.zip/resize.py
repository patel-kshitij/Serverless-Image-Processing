import os
import boto3
from PIL import Image

s3 = boto3.client('s3')

def lambda_handler(event, context):
    # Retrieve bucket name and image key from the S3 event
    bucket_name = event['bucket_name']
    image_key = event['key']
    image_size = event['size']
    
    # Download the original image from S3
    download_path = '/tmp/original_image.jpg'
    s3.download_file(bucket_name, image_key, download_path)
    
    # Open and resize the image
    with Image.open(download_path) as img:
        resized_img = img.resize((image_size, image_size))  # Resize
    
    # Save the resized image to a temporary file
    resized_path = '/tmp/resized_image.jpg'
    resized_img.save(resized_path)
    
    # Upload the resized image back to S3
    resized_key = 'resized/' + os.path.basename(image_key)
    s3.upload_file(resized_path, bucket_name, resized_key)
    
    return {
        'statusCode': 200,
        'body': 'Image resized successfully!'
    }

