import os
import boto3
from PIL import Image

s3 = boto3.client('s3')


def lambda_handler(event, context):
    # Retrieve bucket name, image key, and crop box from the event
    bucket_name = event['bucket_name']
    image_key = event['key']
    crop_box = event['crop_box']  # Format: (left, upper, right, lower)

    # Download the original image from S3
    download_path = '/tmp/original_image.jpg'
    s3.download_file(bucket_name, image_key, download_path)

    # Open and crop the image
    with Image.open(download_path) as img:
        cropped_img = img.crop(crop_box)

    # Save the cropped image to a temporary file
    cropped_path = '/tmp/cropped_image.jpg'
    cropped_img.save(cropped_path)

    # Upload the cropped image back to S3
    cropped_key = 'cropped/' + os.path.basename(image_key)
    s3.upload_file(cropped_path, bucket_name, cropped_key)

    return {
        'statusCode': 200,
        'body': 'Image cropped successfully!'
    }


