import os
import boto3
from PIL import Image, ImageFilter

s3 = boto3.client('s3')


def lambda_handler(event, context):
    bucket_name = event['bucket_name']
    image_key = event['key']
    blur_radius = event['blur_radius']

    # Download the original image from S3
    download_path = '/tmp/original_image.jpg'
    s3.download_file(bucket_name, image_key, download_path)

    # Open and blur the image
    with Image.open(download_path) as img:
        blurred_img = img.filter(ImageFilter.GaussianBlur(radius=blur_radius))

    # Save the blurred image to a temporary file
    blurred_path = '/tmp/blurred_image.jpg'
    blurred_img.save(blurred_path)

    # Upload the blurred image back to S3
    blurred_key = 'blurred/' + os.path.basename(image_key)
    s3.upload_file(blurred_path, bucket_name, blurred_key)

    return {
        'statusCode': 200,
        'body': 'Image blurred successfully!'
    }